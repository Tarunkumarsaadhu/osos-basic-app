package com.example.osospvt;

public class ContactModel {
    String name;
    public  ContactModel(String name)
    {
        this.name=name;
    }


}
