package com.example.osospvt;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<ContactModel> arrContacts=new ArrayList<>();
    String colum[]={
           "Manifest.permission.WRITE_EXTERNAL_STORAGE",
            "Manifest.permission.READ_EXTERNAL_STORAGE"};

    FloatingActionButton fab;
    EditText e1;
    RecyclerView rview;
    private RecyclerView.Adapter adapter;
//    private RecyclerView.LayoutManager;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rview=findViewById(R.id.rview);
        rview.setLayoutManager(new LinearLayoutManager(this));
        if((ActivityCompat.checkSelfPermission(
                this,colum[0])!= PackageManager.PERMISSION_GRANTED)&&
                (ActivityCompat.checkSelfPermission(
                        this,colum[1])!= PackageManager.PERMISSION_GRANTED)){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(colum,123);
            }
        }


        fab=findViewById(R.id.fab);
        arrContacts.add(new ContactModel("papers"));
        arrContacts.add(new ContactModel("flowers"));
        arrContacts.add(new ContactModel("cats"));
        arrContacts.add(new ContactModel("dogs"));
        arrContacts.add(new ContactModel("papers"));
        arrContacts.add(new ContactModel("flowers"));
        arrContacts.add(new ContactModel("cats"));
        arrContacts.add(new ContactModel("dogs"));
        arrContacts.add(new ContactModel("papers"));
        arrContacts.add(new ContactModel("flowers"));
        arrContacts.add(new ContactModel("cats"));
        arrContacts.add(new ContactModel("dogs"));





        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Toast.makeText(getApplicationContext(),"welcome to OSOS PRIVATE LIMITED", Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                ViewGroup viewGroup = findViewById(android.R.id.content);
                View dialogView = LayoutInflater.from(view.getContext()).inflate(R.layout.customview, viewGroup, false);
                builder.setView(dialogView);
                AlertDialog alertDialog = builder.create();

                b1=dialogView.findViewById(R.id.bt1);
                b2=dialogView.findViewById(R.id.bt2);
                e1=dialogView.findViewById(R.id.e1);
               b2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
               b1.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View view) {
                       String r=e1.getText().toString();
                       Toast.makeText(getApplicationContext(),"welcome"+r, Toast.LENGTH_SHORT).show();
                       arrContacts.add(new ContactModel(r));
                     // adapter.notifyItemInserted(arrContacts.size()-1);
                    //   rview.scrollToPosition(arrContacts.size()-1);
                      alertDialog.dismiss();





                   }
               });
                alertDialog.show();




            }
        });
        rview.setLayoutManager(new LinearLayoutManager(this));
        RecyclerContactAdapter adapter=new RecyclerContactAdapter(this,arrContacts);
        rview.setAdapter(adapter);
    }





}